<?php

//[ EN ] Dont Re-Writing This Text Except in Marked xxxxxxxxxxx if you don't want an error
//[ IND ] Dilarang Mengubah Text Ini Selain Yg Bertanda xxxxxxxxxxx Jika Tidak Ingin error


// Input User Agent

$user = 'xxxx';

// Input Wallet Address BTC

$btc = 'xxxx';

//Input Cookie PHPSESSID

$cookie = 'xxxxx';



